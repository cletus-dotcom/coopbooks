CoopBooks Migration Templates
=============================

Import order:
  1. 01_cooperatives.xlsx — Cooperative Profile
  2. 02_accounts.xlsx — Chart of Accounts
  3. 03_users.xlsx — System Users
  4. 04_members.xlsx — Members
  5. 05_journal_entries.xlsx — Journal Entries
  6. 06_journal_lines.xlsx — Journal Lines
  7. 07_member_ledger.xlsx — Member Ledger

Fill each sheet from row 2. Keep column headers unchanged.
Upload via Platform Admin → Migration Tool.
