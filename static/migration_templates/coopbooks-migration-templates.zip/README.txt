CoopBooks Migration Templates
=============================

Single cooperative database — import order:
  1. 01_cooperatives.xlsx — Cooperative Profile (cooperatives)
  2. 02_accounts.xlsx — Chart of Accounts (accounts)
  3. 03_users.xlsx — System Users (users)
  4. 04_members.xlsx — Members (members)
  5. 05_journal_entries.xlsx — Journal Entries (journal_entries)
  6. 06_journal_lines.xlsx — Journal Lines (journal_lines)
  7. 07_member_ledger.xlsx — Member Ledger (member_ledger)

Fill each sheet from row 2. Keep column headers unchanged.
Upload via Administration → Migration Tool (PlatformAdmin role).
